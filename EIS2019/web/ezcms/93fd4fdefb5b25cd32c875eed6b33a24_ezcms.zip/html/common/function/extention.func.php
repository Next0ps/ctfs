<?php
/**
 * extention.func.php   用户自定义函数库
 *
 * @author           袁志蒙  
 * @license          http://www.yzmcms.com
 * @lastmodify       2018-03-18
 */