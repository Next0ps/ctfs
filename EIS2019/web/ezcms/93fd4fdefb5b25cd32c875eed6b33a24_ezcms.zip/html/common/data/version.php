<?php 
//软件摘要信息，****请不要修改或删除本项**** 否则系统无法正确接收系统漏洞或升级信息
define('YZMCMS_VERSION', 'V5.4'); 
define('YZMCMS_UPDATE', '20191020');