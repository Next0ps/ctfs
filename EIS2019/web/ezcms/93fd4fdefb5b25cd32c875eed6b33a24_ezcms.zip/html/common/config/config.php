<?php
return array(

    //系统配置
    'site_theme'         => 'default',    //站点默认主题目录
    'url_html_suffix'    => '.html',      //URL伪静态后缀
    'set_pathinfo'       => false,         //Nginx默认不支持PATHINFO模式，需配置此项为true，则Nginx可支持PATHINFO，系统默认为false
    
    //数据库配置
    'db_type' => 'pdo',     	  // 数据库链接扩展 , 支持 pdo | mysqli | mysql
    'db_host' => 'mysql',  // 服务器地址
    'db_name' => 'yzmcms',		// 数据库名
    'db_user' => 'root',       // 用户名
    'db_pwd' => 'root@3556',       		// 密码
    'db_port' => 3306,         // 端口
    'db_prefix' => 'yzm_',        // 数据库表前缀
    
    //路由配置
    'route'              => array('m' => 'index', 'c' => 'index', 'a' => 'init'),  //默认加载配置，基中“m”为模块,“c”为控制器，“a”为方法
    'route_mapping'      => true,         //是否开启路由映射
    //路由映射规则
    'route_rules'        => array(),
    
    //Cookie配置
    'cookie_domain'      => '',           //Cookie 作用域
    'cookie_path'        => '/',          //Cookie 作用路径
    'cookie_ttl'         => 0,            //Cookie 生命周期，0 表示随浏览器进程
    'cookie_pre'         => 'yzmphp_',    //Cookie 前缀，同一域名下安装多套系统时，请修改Cookie前缀
    'cookie_secure'      => false,        //是否通过安全的 HTTPS 连接来传输 cookie
    
    //缓存配置
    'cache_type'         => 'file',     	// 缓存类型【暂支持 file , redis , memcache 】
    //缓存类型为file缓存时的配置项
    'file_config'        => array (
		'cache_dir'      => YZMPHP_PATH.'cache/chche_file/',    //缓存文件目录
		'suffix'         => '.cache.php',  //缓存文件后缀
		'mode'           => '2',           //缓存格式：mode 1 为serialize序列化, mode 2 为保存为可执行文件array
    ), 
    //缓存类型为redis缓存时的配置项
    'redis_config'       => array (
		'host'           => '127.0.0.1',    // redis主机
		'port'           => 6379,           // redis端口
		'password'       => '',             // 密码
		'select'         => 0,              // 操作库
		'timeout'        => 0,              // 超时时间(秒)
		'expire'         => 3600,           // 有效期(秒)
		'persistent'     => false,          // 是否长连接
		'prefix'         => '',             // 前缀
    ), 
    //缓存类型为memcache缓存时的配置项
    'memcache_config'    => array (
		'host'           => '127.0.0.1',    // memcache主机
		'port'           => 11211,          // memcache端口
		'timeout'        => 0,              // 超时时间(秒)
		'expire'         => 3600,           // 有效期(秒)
		'persistent'     => false,          // 是否长连接
		'prefix'         => '',             // 前缀
    ),
    
    //系统语言
    'language'           => 'zh_cn',      //【暂支持 简体中文zh_cn 和 美式英语en_us】
    
    //附件相关配置
    'upload_file'        => 'uploads',    //上传文件目录，后面一定不要加斜杠（“/”）
    'watermark_enable'   => '1',          //是否开启图片水印
    'watermark_name'     => 'mark.png',   //水印名称
    'watermark_position' => '9',          //水印位置
    
    //其他设置
    'sql_execute'        => false,        //是否允许在线执行SQL命令
    'edit_template'      => false,        //是否允许在线编辑模板

);
?>