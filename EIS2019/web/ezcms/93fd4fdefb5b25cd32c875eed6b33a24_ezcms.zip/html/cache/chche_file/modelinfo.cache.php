<?php
return array (
  'contents' => 
  array (
    0 => 
    array (
      'modelid' => '1',
      'name' => '文章模型',
      'tablename' => 'article',
      'description' => '文章模型',
      'setting' => '',
      'inputtime' => '1466393786',
      'items' => '0',
      'disabled' => '0',
      'type' => '0',
      'sort' => '0',
      'issystem' => '1',
    ),
    1 => 
    array (
      'modelid' => '2',
      'name' => '产品模型',
      'tablename' => 'product',
      'description' => '产品模型',
      'setting' => '',
      'inputtime' => '1466393786',
      'items' => '0',
      'disabled' => '0',
      'type' => '0',
      'sort' => '0',
      'issystem' => '1',
    ),
    2 => 
    array (
      'modelid' => '3',
      'name' => '下载模型',
      'tablename' => 'download',
      'description' => '下载模型',
      'setting' => '',
      'inputtime' => '1466393786',
      'items' => '0',
      'disabled' => '0',
      'type' => '0',
      'sort' => '0',
      'issystem' => '1',
    ),
  ),
  'expire' => 0,
  'mtime' => 1573355506,
);
?>