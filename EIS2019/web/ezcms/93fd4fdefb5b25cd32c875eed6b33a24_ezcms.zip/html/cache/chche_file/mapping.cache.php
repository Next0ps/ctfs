<?php
return array (
  'contents' => 
  array (
    '^xinwenzhongxin$' => 'index/index/lists/catid/1',
    '^xinwenzhongxin\\/list_(\\d+)$' => 'index/index/lists/catid/1/page/$1',
    '^xinwenzhongxin\\/(\\d+)$' => 'index/index/show/catid/1/id/$1',
    '^guanfangxinwen$' => 'index/index/lists/catid/2',
    '^guanfangxinwen\\/list_(\\d+)$' => 'index/index/lists/catid/2/page/$1',
    '^guanfangxinwen\\/(\\d+)$' => 'index/index/show/catid/2/id/$1',
    '^qitaxinwen$' => 'index/index/lists/catid/3',
    '^qitaxinwen\\/list_(\\d+)$' => 'index/index/lists/catid/3/page/$1',
    '^qitaxinwen\\/(\\d+)$' => 'index/index/show/catid/3/id/$1',
    '^guanyuwomen$' => 'index/index/lists/catid/4',
  ),
  'expire' => 0,
  'mtime' => 1573355494,
);
?>