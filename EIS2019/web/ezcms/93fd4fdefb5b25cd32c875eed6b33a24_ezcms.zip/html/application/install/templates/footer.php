<?php defined('IN_YZMCMS') or exit('No Define YzmCMS.'); ?>
<div class="footer">Powered By <a href="http://www.yzmcms.com/" target="_blank">www.yzmcms.com</a> © 2014-2020 袁志蒙工作室</div>