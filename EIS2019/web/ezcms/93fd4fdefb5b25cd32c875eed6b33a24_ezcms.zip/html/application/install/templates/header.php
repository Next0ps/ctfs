<?php defined('IN_YZMCMS') or exit('No Define YzmCMS.'); ?>
<div class="header">
    <h1 class="logo">YzmCMS内容管理系统</h1>
    <div class="icon_install">安装向导</div>
    <div class="version"><?php echo VERSION;?></div>
</div>