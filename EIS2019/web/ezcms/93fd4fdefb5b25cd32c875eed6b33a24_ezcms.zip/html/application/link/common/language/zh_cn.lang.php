<?php
/**
 * @explain  		 YZMCMS 简体中文语言包
 * @author           袁志蒙  
 * @license          http://www.yzmcms.com
 */
return array( 
	'link' => '友情链接',
	'add_link' => '添加友情链接',
	'edit_link' => '编辑友情链接',
	'del_link' => '删除友情链接',
	'apply_link' => '友情链接申请',
	'close_apply_link' => '站点已关闭友情链接申请',
	'apply_link_success' => '友情链接申请成功，等待管理员审核',
);