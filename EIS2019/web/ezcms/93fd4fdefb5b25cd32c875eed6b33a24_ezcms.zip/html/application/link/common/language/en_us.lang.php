<?php
/**
 * @explain  		 YZMCMS English language package
 * @author           袁志蒙  
 * @license          http://www.yzmcms.com
 */
return array( 
	'link' => 'Friendship link',
	'add_link' => 'Add link',
	'edit_link' => 'Edit link',
	'del_link' => 'Delete link',
	'apply_link' => 'Apply link',
	'close_apply_link' => 'Website close apply link',
	'apply_link_success' => 'Apply success, Wait for audit',
);