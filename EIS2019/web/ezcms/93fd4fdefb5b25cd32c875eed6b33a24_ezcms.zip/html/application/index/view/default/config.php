<?php return array (
  'name' => '默认模板',
  'author' => '袁志蒙',
  'dirname' => 'default',
  'version' => '1.0',
  
  //频道页模板
  'category_temp' =>  
  array (
		'category_article' => '文章频道页模板', 
		'category_product' => '产品频道页模板',
		'category_download' => '下载频道页模板',
		'category_page' => '单页面模板', 		
  ),
  
  
  //列表页模板
  'list_temp' =>  
  array (
		'list_article' => '文章列表页模板', 
		'list_article_img' => '文章图片列表页模板', 
		'list_product' => '产品列表页模板',
		'list_download' => '下载列表页模板',
		'list_diyform' => '自定义表单列表模板', 		
  ),
  
  
   //内容页模板
  'show_temp' => 
  array (
	    'show_article' => '文章内容页模板', 
	    'show_product' => '产品内容页模板', 
	    'show_download' => '下载内容页模板', 
	    'show_diyform' => '自定义表单内容页模板', 
  ) 
  
);?>